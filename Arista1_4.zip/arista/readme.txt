=== Arista ===

This is the theme for Arista Enterprises. Some info about this thme:
	- theme is built to serve static content via pages
		- However, the "Posts" system can be utilized to display posts.
		- The "comment" system could possibly be utilized for "contact page"
		- However, contact page could also send an email
	- mobile version of website does not display sub items. This could be
	swapped out with a simple javascript or jquery script to collapse and expand items.
------------------------------
=== File Structure ===
 /arista
	fonts/
	inc/
		custom-header.php
		customizer.php
		jetpack.php
		template-functions.php
		template-tags.php
	js/
		customizer.js
		navigation.js
		skip-link-focus-fix.js
	languages/
	layouts/
		content-sidebar.css
		sidebar-content.css
	template-parts/
		content.php
		content-none.php
		content-page.php
		content-search.php
	404.php
	archive.php
	comments.php
	footer.php
	functions.php
	header.php
	index.php
	page.php
	search.php
	sidebar.php
	style.css
------------------------------
Requires at least: 4.5
Tested up to: 4.8
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

A starter theme called Arista.

== Description ==

A theme for the company: Arista Enterprises.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 10/21/2019 = Pre-beta design - Tyler Ruff


== Credits ==
Kyle Hansen
Tyler Ruf
