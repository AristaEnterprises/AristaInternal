<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Arista
 */

?>

	</div><!-- #content -->
	</div><!-- #page -->
	<!-- footer item is not part of page to preserve 100% background -->
	<footer id="colophon" class="site-footer">
	<div class="sidebarbottom">
		<aside id="thefooter" class="widget-area"><section id="text-2" class="widget widget_text">	
		<div class="textwidget">
		<p><a href="tel:+1(833) 474-8884">+1 (833) 474-8884 ext 2</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="mailto:cdantonio@aeprise.com">cdantonio@aeprise.com</a></p>
		<p>©<?php echo date("Y"); ?> All Rights Reserved, Arista Enterprises, LLC.</p>
		</div>
		</section></aside><!-- #secondary -->
	</div>
	</footer><!-- #colophon -->


<?php wp_footer(); ?>

</body>
</html>
