Arista Enterprises Website
V.1.2
https://github.com/AristaEnterprises/AristaInternal/tree/1.2
-----------------------------------------------------------
BIG CHANGESET
1. Added picture banner (may not be reflected in changeset exports)
2. Added many other pictures
3. Added call to action boxes
4. Small fixes
-----------------------------------------------------------
Active Plugins:
-W3 Total Cache

-White Label CMS

-Wordpress Importer
-----------------------------------------------------------
Site theme framework: Underscores
(c) 2019 Arista Enterprises